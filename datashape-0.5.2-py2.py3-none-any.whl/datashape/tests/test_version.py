def test_version():
    import datashape
    assert datashape.__version__ != 'unknown'
